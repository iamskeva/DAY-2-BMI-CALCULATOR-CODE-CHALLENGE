#BMI CALCULATOR CODE CHALLENGE

# The BMI is calculated by dividing a person's weight (in kg) by the square of their height (in m):

height = input("enter your height in m: ")
weight = input("enter your weight in kg: ")


# I converted the string output into "float" and "int"

squareHeight = float(height)
addWeight = int(weight)

#Now the BMI Formula will now be

BMI = addWeight / (squareHeight ** 2)
print(int(BMI))